﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ3_NetworkService.Model
{
    public static class Kolekcija
    {
        private static ObservableCollection<Merilo> allObjects = new ObservableCollection<Merilo>();

        public static ObservableCollection<Merilo> AllObjects { get => allObjects; set => allObjects = value; }
        public static string CurrentWindow { get => currentWindow; set => currentWindow = value; }

        private static string currentWindow;
    }
}
