﻿using PZ3_NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ3_NetworkService.ViewModel
{
    public class MeriloViewModel :  BindableBase
    {

        int minValue = 670;
        int maxValue = 735;
        private string networkTerminal;
        private string networkTerminal2;

        public MyICommand<string> NetworkCommand { get; private set; }



        private ObservableCollection<Merilo> mjerila = new ObservableCollection<Merilo>();






        public ObservableCollection<Merilo> Mjerila {

            get { return mjerila; }

            set
            {

                if (mjerila != value)
                {
                    mjerila = value;
                    OnPropertyChanged("Mjerila");
                }
            }

        }

        public string NetworkTerminal {

            get { return networkTerminal; }
            set
            {
                if (networkTerminal != value)
                {
                    networkTerminal = value;
                    OnPropertyChanged("NetworkTerminal");
                }
            }

        }

        public string NetworkTerminal2
        {
            get { return networkTerminal2; }
            set
            {
                if (networkTerminal2 != value)
                {
                    networkTerminal2 = value;
                    OnPropertyChanged("NetworkTerminal2");
                }
            }
        }

        public MeriloViewModel()
        {
            Mjerila.Clear();
            networkTerminal2 = ">>";
            

            NetworkCommand = new MyICommand<string>(OnNav);

            foreach (Merilo m in Kolekcija.AllObjects)
            {
                Mjerila.Add(new Merilo(m.Id, m.Name, m.Tip, m.Valuee));
            }

            //Mjerila.Add(new Merilo("asd", "luka", new Tip("asd", ""), 122));


            
        }


        private void OnNav(string destination)
        {
            if (destination == "enter")
            {
                switch (NetworkTerminal)
                {
                    case "networkData":
                        MainWindowViewModel.currentViewModel = MainWindowViewModel.networkDataViewModel;
                        MainWindowViewModel.RisePropChanged();
                        break;
                       



                }

            }
        }
    }
}
