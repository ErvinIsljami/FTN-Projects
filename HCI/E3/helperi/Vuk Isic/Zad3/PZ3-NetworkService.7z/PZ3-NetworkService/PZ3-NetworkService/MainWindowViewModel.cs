﻿using PZ3_NetworkService.Model;
using PZ3_NetworkService.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ3_NetworkService
{
    public delegate void Changed();
    public class MainWindowViewModel : BindableBase
    {
        public MyICommand<string> NavCommand { get; private set; }
        public static NetworkDataViewModel networkDataViewModel = new NetworkDataViewModel();
        public static MeriloViewModel homeViewModel = new MeriloViewModel();
        private ReportViewModel reportViewModel = new ReportViewModel();
        private DataChartViewModel dataChartViewModel = new DataChartViewModel();
        public static BindableBase currentViewModel;
        public static event Changed PropChanged;
        private string term;
        private string term2;
        //public string CurrentState { get; set; }



        public MainWindowViewModel()
        {
            NavCommand = new MyICommand<string>(OnNav);
            CurrentViewModel = homeViewModel;
            PropChanged += x;
            //CurrentState = "networkView";

        }

        public BindableBase CurrentViewModel
        {
            get { return currentViewModel; }
            set
            {
                SetProperty(ref currentViewModel, value);
            }
        }

        /*public string Term {

            get { return term; }
            set
            {
                if (term != value)
                {
                    term = value;
                    OnPropertyChanged("Term");
                }
            }
            
        }

        public string Term2
        {

            get { return term2; }
            set
            {
                if (term2 != value)
                {
                    term2 = value;
                    OnPropertyChanged("Term2");
                }
            }

        }*/

        private void OnNav(string destination)
        {
            /*if (destination == "enter")
            {

                switch (Term2)
                {
                    case "Input Id:":
                        if (CurrentState == "networkDataView")
                        {
                            
                        }
                        break;
                }

                switch (Term)
                {
                    case "networkDataView":

                        CurrentViewModel = networkDataViewModel;
                        CurrentState = "networkDataView";
                        Term = "";
                        break;

                    case "networkView":

                        CurrentViewModel = homeViewModel;
                        CurrentState = "networkView";
                        Term = "";
                        break;
                    case "delete":

                        if (CurrentState == "networkDataView")
                        {
                            Term2 = "Input Id:";
                            Term = "";
                        }
                        break;

                    default:

                        Term = "";
                        break;

                }
            
            }*/


            switch (destination)
            {
                case "view1":
                    CurrentViewModel = homeViewModel;
                    break;
                case "view2":
                    CurrentViewModel = networkDataViewModel;
                    break;
            }
        }

        public static void RisePropChanged()
        {
            PropChanged();
        }
        public void x()
        {
            OnPropertyChanged("CurrentViewModel");
        }
    }
    
}
