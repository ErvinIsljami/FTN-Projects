﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ3_NetworkService.Model
{
    public class Tip
    {
        public string Name { get; set; }
        public string Img_Src { get; set; }

        public Tip() { }

        public Tip(string name, string img)
        {
            this.Name = name;
            this.Img_Src = img;
        }
    }
}
